﻿namespace trade
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            label2 = new Label();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            label3 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F);
            label1.Location = new Point(20, 21);
            label1.Name = "label1";
            label1.Size = new Size(205, 30);
            label1.TabIndex = 0;
            label1.Text = "Please select a bank";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(30, 54);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(70, 24);
            checkBox1.TabIndex = 1;
            checkBox1.Text = "Chase";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(30, 84);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(140, 24);
            checkBox2.TabIndex = 2;
            checkBox2.Text = "Bank of America";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(30, 114);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(59, 24);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "PNC";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13F);
            label2.Location = new Point(20, 163);
            label2.Name = "label2";
            label2.Size = new Size(381, 30);
            label2.TabIndex = 4;
            label2.Text = "Please select the type of bank account";
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(30, 205);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(91, 24);
            checkBox4.TabIndex = 5;
            checkBox4.Text = "Checking";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(30, 235);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(81, 24);
            checkBox5.TabIndex = 6;
            checkBox5.Text = "Savings";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13F);
            label3.Location = new Point(20, 287);
            label3.Name = "label3";
            label3.Size = new Size(101, 30);
            label3.TabIndex = 7;
            label3.Text = "Amount :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(127, 292);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 8;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(678, 404);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 9;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(label2);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private Label label2;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private Label label3;
        private Button button1;
        public TextBox textBox1;
    }
}
