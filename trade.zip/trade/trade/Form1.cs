namespace trade
{
    public partial class Form1 : Form
    {
        public string? amount ;
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            amount = textBox1.Text;
        }
        
        
        
        private void button1_Click(object sender, EventArgs e)
        {
            if(amount == null)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }
            else {
                Form3 form3 = new Form3();
                form3.label3.Text = amount;
                form3.Show();
                this.Hide();
                
            }
            
        }
    }
}
