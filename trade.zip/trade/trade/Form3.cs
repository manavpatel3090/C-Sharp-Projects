﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace trade
{

    public partial class Form3 : Form
    {
        Random random = new Random();
        stock_info selected_Stock = new stock_info();
        //Dictionary<stock_info> selected_Stock = new Dictionary<stock_info>();
        Form1 form1 = new Form1();
        double d_amount;
        Dictionary<int, stock_info> stock_Dict = new Dictionary<int, stock_info>
        {
            {
                0, new stock_info {stock_Name = "NVIDIA", stock_Price=55.34, market_Cap=500, user_stock = 100}
            },
            {
                1, new stock_info {stock_Name = "GOOGLE", stock_Price=35.65, market_Cap=500, user_stock = 100}
            },
            {
                2, new stock_info {stock_Name = "APPLE", stock_Price=60.43, market_Cap=500, user_stock = 100}
            },
            {
                3, new stock_info {stock_Name = "SAMSUNG", stock_Price=37.89, market_Cap=500, user_stock = 100}
            },
            {
                4, new stock_info {stock_Name = "META", stock_Price=60.12, market_Cap=500, user_stock = 100}
            }
        };
        public void balance(string balance)
        {
            string? var_balance = form1.amount;
            d_amount = Convert.ToInt32(var_balance);
        }
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            index_data(index);
        }
        public void index_data(int index)
        {

            selected_Stock = stock_Dict[index];
            //var r = selected_Stock.GetType();
            label6.Text = selected_Stock.stock_Price.ToString();
            label8.Text = selected_Stock.market_Cap.ToString();
            label11.Text = selected_Stock.user_stock.ToString();

        }

        public void operations_buy(int action_num, bool buy_sell, int dict_index)
        {
            d_amount = Convert.ToDouble(label3.Text);
            if (buy_sell && d_amount >= stock_Dict[dict_index].stock_Price * action_num)
            {

                stock_Dict[dict_index].market_Cap -= action_num;
                d_amount -= stock_Dict[dict_index].stock_Price * action_num;
                stock_Dict[dict_index].user_stock += action_num;
                label3.Text = d_amount.ToString();
                index_data(dict_index);
            }
            else
            {
                MessageBox.Show("Insufficient Funds!!");
            }
        }

        public void operations_sell(int action_num, bool buy_sell, int dict_index)
        {
            d_amount = Convert.ToDouble(label3.Text);
            if (!buy_sell && stock_Dict[dict_index].user_stock >= action_num)
            {
                stock_Dict[dict_index].market_Cap += action_num;
                d_amount += stock_Dict[dict_index].stock_Price * action_num;
                stock_Dict[dict_index].user_stock -= action_num;
                label3.Text = d_amount.ToString();
                index_data(dict_index);
            }
            else
            {
                MessageBox.Show("Insufficient Stocks to sell!!");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int action_num = Convert.ToInt32(textBox1.Text);
            int dict_index = comboBox1.SelectedIndex;
            
            if(radioButton1.Checked == true)
            {
                operations_buy(action_num, true, dict_index);
            }
            else if(radioButton2.Checked == true)
            {
                operations_sell(action_num, false, dict_index);
            }
            else
            {
                MessageBox.Show("Please Select an option to buy or sell");
            }
            
        }
    }
}
public class stock_info
{
    public string stock_Name { get; set; }
    public double stock_Price { get; set; }
    public int market_Cap { get; set; }
    public int user_stock { get; set; }
}
