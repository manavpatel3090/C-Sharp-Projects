﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace trade2._0
{
    public partial class Form1 : Form
    {
        double balance =0;
        stock_info selected_Stock = new stock_info();
        Dictionary<int, stock_info> stock_Dict = new Dictionary<int, stock_info>
        {
            {
                0, new stock_info {stock_Name = "NVIDIA", stock_Price=55.34, market_Cap=500, user_stock = 100}
            },
            {
                1, new stock_info {stock_Name = "GOOGLE", stock_Price=35.65, market_Cap=500, user_stock = 100}
            },
            {
                2, new stock_info {stock_Name = "APPLE", stock_Price=60.43, market_Cap=500, user_stock = 100}
            },
            {
                3, new stock_info {stock_Name = "SAMSUNG", stock_Price=37.89, market_Cap=500, user_stock = 100}
            },
            {
                4, new stock_info {stock_Name = "META", stock_Price=60.12, market_Cap=500, user_stock = 100}
            }
        };
        Dictionary<int, int> user_Stock = new Dictionary<int, int>
        {
            {0,0}, {1,0}, {2,0}, {3,0}, {4,0}
        };
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            balance += Convert.ToDouble(textBox1.Text);
            tabControl1.SelectedTab = tabPage3;
            label18.Text = balance.ToString();
            label36.Text = balance.ToString();
        }

        private void portfolio_update()
        {
            label26.Text = user_Stock[0].ToString();
            label27.Text = user_Stock[1].ToString();
            label28.Text = user_Stock[2].ToString();
            label29.Text = user_Stock[3].ToString();
            label30.Text = user_Stock[4].ToString();
            label32.Text = balance.ToString();
        }

        public void operations_buy(int action_num, bool buy_sell, int dict_index)
        {

            if (buy_sell && balance >= stock_Dict[dict_index].stock_Price * action_num)
            {
                stock_Dict[dict_index].market_Cap -= action_num;
                balance -= stock_Dict[dict_index].stock_Price * action_num;
                user_Stock[dict_index] += action_num;
                label18.Text = balance.ToString();
                label36.Text = balance.ToString();
                index_data(dict_index);
                portfolio_update();
            }
            else
            {
                MessageBox.Show("Insufficient Funds!!");
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            int action_num = Convert.ToInt32(textBox2.Text);
            int dict_index = comboBox3.SelectedIndex;
            operations_buy(action_num, true, dict_index);
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox3.SelectedIndex;
            index_data(index);
        }
        public void index_data(int index)
        {
            selected_Stock = stock_Dict[index];
            label12.Text = selected_Stock.stock_Price.ToString();
            label15.Text = selected_Stock.market_Cap.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }
        public void operations_sell(int action_num, bool buy_sell, int dict_index)
        {
            if (buy_sell && stock_Dict[dict_index].user_stock >= action_num)
            {
                stock_Dict[dict_index].market_Cap += action_num;
                balance += stock_Dict[dict_index].stock_Price * action_num;
                user_Stock[dict_index] -= action_num;
                label18.Text = balance.ToString();
                label36.Text = balance.ToString();
                index_data2(dict_index); 
                portfolio_update();
            }
            else
            {
                MessageBox.Show("Insufficient Stocks to sell!!");
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            int action_num = Convert.ToInt32(textBox3.Text);
            int dict_index = comboBox4.SelectedIndex;
            operations_sell(action_num, true, dict_index);
        }
        
        public void index_data2(int index)
        {
            selected_Stock = stock_Dict[index];
            label41.Text = selected_Stock.stock_Price.ToString();
            label38.Text = user_Stock[index].ToString();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox4.SelectedIndex;
            index_data2(index);
        }
    }
}

public class stock_info
{
    public string stock_Name { get; set; }
    public double stock_Price { get; set; }
    public int market_Cap { get; set; }
    public int user_stock { get; set; }
}
